# VEYA kiosk (linuxfb) on tty1
if [ -z "$DISPLAY" ] && [ "$(tty)" = "/dev/tty1" ]; then
    export QT_QPA_PLATFORM=linuxfb

        # Start VEYA (single entrypoint)
    exec /home/pfe/veya/start_veya.sh
fi

